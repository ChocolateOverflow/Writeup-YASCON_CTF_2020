import base64 
import codecs

def y(q):
    q=q.decode('utf-8')
    key = 13
    out = ''
    for i in q:
        newchar = chr(ord(i)^key)
        out = out + newchar
    return out

def x(q):
    return q[::-1]

def z(q):
    q=str(q).encode('utf-8')
    return base64.b64encode(q)

def s(q):
    q=q.encode('utf-8')
    return codecs.encode(q,'hex')


def p(q):
    q=q.decode('utf-8')
    return codecs.encode(q,'rot_13')

def o(q):
    q=q.decode('utf-8')
    return codecs.encode(q,'punycode')

def n(q):
    q=q.encode('utf-8')
    return base64.b16encode(q)

def shift1(q):
    out = [0]*len(q)
    for i in range(len(q)):
        out[(i+1)%len(q)] = q[i]
    return ''.join(out)  

if __name__ == '__main__':
    flag = input().strip()
    print(flag)
    print(result)
    with open('ciphertext.txt','w') as write:
        write.write(result)
    write.close()
